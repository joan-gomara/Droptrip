using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// afegim UI per la classe Button
using UnityEngine.UI;
// agefim TMP per el text
using TMPro;


public class GameSceneUI : MonoBehaviour
{

    public float lives;
    [SerializeField] TMP_Text textScore;
    [SerializeField] Button menuButton;

     void Start()
    {
        textScore.text = "Vides: " + lives.ToString();

        menuButton.onClick.AddListener(LoadMenu);
    }

    void Update()
    {
        lives = GameManager.Instance._lives;
        textScore.text = "Vides: " + lives.ToString();
    }

    void LoadMenu()
    {
        Loader.Load(Loader.Scene.MainMenu);
    }
}
