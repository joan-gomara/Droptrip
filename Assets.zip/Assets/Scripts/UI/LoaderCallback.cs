using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoaderCallback : MonoBehaviour
{
    //variable per definir si es la primera actualització
    private bool isFirstUpdate = true;

    private void Update()
    {
        //un cop actualitzem la pantalla carreguem el retorn del Loader
        if(isFirstUpdate)
        {
            isFirstUpdate = false;
            Loader.LoaderCallback();
        }
    }
}
