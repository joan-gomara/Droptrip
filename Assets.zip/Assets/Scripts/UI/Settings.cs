using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Settings : MonoBehaviour
{
    [SerializeField] Button menuButton;
    [SerializeField] Button testButton;

    private void Start()
    {
        menuButton.onClick.AddListener(LoadMenu);
        testButton.onClick.AddListener(LoadTest);
    }

    void LoadMenu()
    {
        Loader.Load(Loader.Scene.MainMenu);
    }
    void LoadTest()
    {
        Loader.Load(Loader.Scene.SampleScene);
    }
}
