using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

    private Rigidbody2D rb2D;

    private float moveSpeed;
    public float moveHorizontal;

    private float jumpForce;
    private int totalJump;
    private int maxJump;
    private bool isJumping;


    PlayerBehaviour _playerBehaviour;
    [SerializeField] Staminabar _staminabar;


    void Start()
    {
        rb2D = gameObject.GetComponent<Rigidbody2D>();
        _playerBehaviour = GameObject.Find("Player").GetComponent<PlayerBehaviour>();

        _staminabar.SetMaxStamina(GameManager.Instance._playerStamina.MaxStamina);
        GameManager.Instance._lives = GameManager.Instance._maxLives;

        
        moveSpeed = 1f;

        jumpForce = 30f;
        totalJump = 0;
        maxJump = 2;
        isJumping = false;

    }


    void Update()
    {
        // left = -1 , no = 0 , right = 1 
        //moveHorizontal = Input.GetAxisRaw("Horizontal");

        //constantment gasta stamina
        PlayerWasteStamina();

        // Salta si toca al terra i permet un doble salt
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.RightArrow))
        {
            if (!isJumping)
            {
                PlayerUseStamina(400f);
                rb2D.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
            }
            else if (isJumping && totalJump < maxJump)
            {
                PlayerUseStamina(1000f);
                totalJump++;
                rb2D.velocity = new Vector2(rb2D.velocity.x, 0f);
                rb2D.AddForce(new Vector2(moveHorizontal * moveSpeed*10, jumpForce), ForceMode2D.Impulse);
            }
        }

        
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.LeftArrow))
        {
            if (!isJumping)
            {
                PlayerUseStamina(10f);
                moveHorizontal = 0f;
            }
        }
        else
        {
            moveHorizontal = 1f;
            //aqui podem afegirles mecàniques per girar el personatge en nivells avançats
        }


        // stamina = 0 -> Game Over
        if (GameManager.Instance._playerStamina.Stamina <= 0)
        {
            GameOver();
        }

    }

    // Update with phisic engine inside Unity
    private void FixedUpdate()
    {
        if(moveHorizontal > 0.1f || moveHorizontal < -0.1f)
        {
            rb2D.AddForce(new Vector2(moveHorizontal * moveSpeed, 0f), ForceMode2D.Impulse);
            //print(moveSpeed);
        }
    }






    // Funcions colisionadors

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Platform"))
        {
            totalJump = 0;
            isJumping = false;
        }

        // Death, Respawn, Restart 
        if (collision.CompareTag("Death"))
        {
            totalJump = 0;
            isJumping = false;
            if (GameManager.Instance._lives > 0)
            {
                GameManager.Instance._lives--;
                // carreguem la posició del checkpoint si tenim vides disponibles i hi ha algun checkpoint guardat
                //podriem crear tambe un checkpoint cada vegada que és iniat un nivell
                if(SaveManager.SavedataExists())
                {
                    _playerBehaviour.LoadPos();
                }
                
            }
            else
            {
                GameOver();
            }
        }
        if (collision.CompareTag("Finish"))
        {
            _playerBehaviour.StartPos();

            GameManager.Instance._level++;
            Loader.Load(Loader.Scene.MainMenu);
        }
        if (collision.CompareTag("Respawn"))
        {
            _playerBehaviour.SavePos();
            //busquem per el nom i eliminem l'objecte
            Destroy(GameObject.Find("Respawn"));
        }
    }


    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Platform"))
        {
            // Es resta el salt inicial al sortir d'una superfície.
            totalJump++;
            isJumping = true;
        }
    }


    // Funcions stamina

    private void PlayerUseStamina(float staminaAmount)
    {
        GameManager.Instance._playerStamina.UseStamina(staminaAmount);
        _staminabar.SetStamina(GameManager.Instance._playerStamina.Stamina);
    }

    private void PlayerWasteStamina()
    {
        GameManager.Instance._playerStamina.WasteStamina();
        _staminabar.SetStamina(GameManager.Instance._playerStamina.Stamina);
    }


    private void GameOver()
    {
        Loader.Load(Loader.Scene.GameOver);
        print("Game Over");

        // Restablir els valors del savemanager
        _playerBehaviour.StartPos();
        totalJump = 0;
        isJumping = false;
        GameManager.Instance._lives = GameManager.Instance._maxLives;

    }
}
