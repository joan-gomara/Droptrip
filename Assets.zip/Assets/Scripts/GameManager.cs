using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    // es pot accedir directament als objectes d'aquesta claase des de qualsevol script 
    public static GameManager Instance{ get; private set; }


    // Es crea l'objecte i la stamina del jugador amb la classe creada anteriorment
    // d'aquesta manera podem crear varis jugadors o enemics amb una stamina determinada
    public UnitStamina _playerStamina = new UnitStamina(100f, 100f, 2f, false);

    public int _level = 0;
    public int _lives;
    public int _maxLives = 3;


    void Awake()
    {
        if (true)
        {
            
            if (Instance != null && Instance != this)
            {
                //if there are duplicate destroy it
                Destroy(this);
            }
            else
            {
                Instance = this;
            }
        }
    }

}
